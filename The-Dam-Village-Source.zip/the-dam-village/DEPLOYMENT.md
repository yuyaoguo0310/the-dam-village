# Deployment and launch

Live student entry: https://the-dam-village-classroom.basiccrab7.chatgpt.site/

Live host entry: https://the-dam-village-classroom.basiccrab7.chatgpt.site/admin

Live group guide entry: https://the-dam-village-classroom.basiccrab7.chatgpt.site/guide

Published through Sites with a Cloudflare Worker and persistent D1 database. Student visitors do not need an account. Each classroom has a separate random host recovery key and four guide keys. The host creates a fresh classroom and shares its student link/code using Invite & keys.

No backend configuration is needed for the live site. Use README.md for hosting another copy, classroom flow, and recovery. Local backup: double-click Launch The Dam Village.command; an Apple Silicon Node runtime is bundled in runtime/. For Intel Macs and other systems use an installed Node 18+.

Verified on October 13, 2026: public production page, persistent database, nine simultaneous student joins, four guides, automatic balancing, both voting rounds, paired change counts, and both future controls. Automated local tests also cover 21 concurrent students. This does not substitute for a rehearsal on your classroom projector and students’ actual devices.
