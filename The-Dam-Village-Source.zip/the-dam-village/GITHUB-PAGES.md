# GitHub Pages deployment

The frontend in `docs/index.html` can run on GitHub Pages. The browser URL is `https://yuyaoguo0310.github.io/the-dam-village/` and host entry is `?view=host`; guide entry is `?view=guide`. It connects to the existing HTTPS Worker for persistent room data and voting. The backend hostname still contains `chatgpt.site`; it is not the visible website URL. To remove that provider completely, deploy `worker/index.js` with your own Cloudflare/D1 setup and rebuild the frontend with `DAM_API_ORIGIN=https://your-worker.example node build-pages.mjs`.

1. Upload this source repository with the generated `docs/` directory.
2. In Settings → Pages, choose Deploy from a branch, branch main, folder `/docs`, then Save.
3. The backend must set `PUBLIC_FRONTEND_ORIGINS=https://yuyaoguo0310.github.io`. This is an exact-origin allowlist, not a wildcard. Origin validation and independent room/host/guide credentials remain enforced. Re-publish after changing the runtime setting.
4. Open the live Pages site, create a room, and share its new QR code/student link. QR codes are generated locally, with a four-module white border. They contain only the student link and room code, never the host/guide keys.

For hosting the backend on Sites, `node build.mjs` bundles all assets and the D1 migration. For normal local backup, `node server.mjs` works without dependency installation.

The original complete source is included: `index.html`, `engine.mjs`, `api.mjs`, `server.mjs`, builders, SQL migration, tests, and the MIT-licensed vendored QR generator. Runtime classroom data and access credentials must never be committed. The repository excludes `.local/`, `.git/`, and the bundled Node runtime.
