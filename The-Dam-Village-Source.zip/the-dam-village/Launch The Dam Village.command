#!/bin/bash
set -e
cd "$(dirname "$0")"
if command -v node >/dev/null 2>&1; then
  dam_node="$(command -v node)"
elif [ -x "runtime/node" ]; then
  dam_node="runtime/node"
elif [ -x "../../work/package/bin/node" ]; then
  dam_node="../../work/package/bin/node"
else
  echo 'Install Node.js 18 or newer, then run this launcher again.'
  read -r -p 'Press Return to close.'
  exit 1
fi
printf '\nHost dashboard: http://localhost:8787/admin\nPhones on the same allowed network can use:\n'
for dam_interface in en0 en1; do
  dam_ip="$(ipconfig getifaddr "$dam_interface" 2>/dev/null || true)"
  if [ -n "$dam_ip" ]; then printf 'http://%s:8787/\n' "$dam_ip"; fi
done
printf 'Keep this window open. Control-C stops the classroom.\n\n'
open 'http://localhost:8787/admin'
exec "$dam_node" server.mjs
