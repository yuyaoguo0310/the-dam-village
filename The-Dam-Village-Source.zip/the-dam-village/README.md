# The Dam Village

English-language, real multi-device classroom app for UCSB ENVS 156. No student accounts, no remote third-party scripts, a vendored MIT QR generator, and no npm installation. The student entry is `/`, the host dashboard is `/admin`, and the guide entry is `/guide`.

## Run a classroom

1. Open the host dashboard, choose **Create classroom**, and save the host recovery key privately. The room has its own unpredictable host credential; knowing its join code does not grant control.
2. Choose **Invite & keys**. Share the student link/code with students. Share each guide key only with the insider for that group. Guides select their group, are excluded from balancing and voting, and can submit a group recommendation.
3. Advance through Welcome → First vote → Group discussion → Debate → Final vote → Two futures. Discussion defaults to six minutes; debate defaults to five. Pause/resume/set the timer as needed. Timers do not advance phases. Closing a vote with outstanding submissions requires confirmation.
4. In both votes, students choose Support, Oppose, or Support with Conditions. They may amend their choice until that round closes. No host/guide response exposes individual choices. The host sees only submission status until anonymous final results appear.
5. Use **If we build the dam** to play a roughly 9-second staged scenario: reservoir construction, electricity/irrigation benefits, then ecological/community costs. Benefits and costs coexist in the final state. **Explore alternatives** plays a 7-second portfolio reveal with solar/storage, groundwater recharge and efficient irrigation, with both opportunities and limits.
6. **Projector view** hides host controls; Exit projector restores them. Use an extended display or a second host tab for controls while projecting. Never project the Invite & keys dialog. Download anonymous results as CSV after the final vote.
7. Choose **New classroom** for a new activity; old results stay available with the original host key.

## Rejoining and allocation

Identity is saved separately for student, guide and host on the same browser. Refreshing, briefly disconnecting, or rejoining with the same recovery key keeps the role and votes. Students can find their key with **My entry key**. On a different device, use **Already joined on another device?** and the original room code/key. Host recovery is available on the host entry.

New students join the currently smallest student group, so student allocations differ by at most one. Existing students never move groups. Offline identities remain counted so a reconnect cannot cause reassignment. Duplicate nicknames are rejected, not silently merged. A group accepts one guide. Late arrivals can join until results; a missed first vote remains unpaired in change statistics. Maximum room size is 200 students plus four guides. Without accounts, one human can deliberately make multiple identities with new browsers/nicknames; this is a classroom trust model, not an election system.

## Local launch / backup

On this Mac, double-click **Launch The Dam Village.command**. It uses the bundled Apple Silicon Node runtime, or an installed Node 18+ runtime. Keep the Terminal window open; Control-C stops the server. Host: `http://localhost:8787/admin`.

From a normal checkout with Node 18+: `node server.mjs` (or `npm start`). There is nothing to install. To test: `node --test tests/*.test.mjs`. To build the hosted Worker: `node build.mjs`.

Phones need the host computer’s LAN address, e.g. `http://192.168.1.10:8787/`, on the same network. The launcher prints usable network links. `localhost` on a phone points to the phone itself. Campus Wi-Fi may isolate devices; use the hosted site or an allowed shared network. Allow incoming connections if macOS asks. Local HTTP is intended for a trusted classroom LAN; use HTTPS for Internet hosting.

Local rooms persist in `.local/rooms.json`. Back up that directory if needed. It contains sensitive host/guide credentials and private votes; do not share it or put it in a public repository. The supplied archive excludes classroom data. This single-process local server serializes disk writes. Do not run multiple instances against the same data file.

## Hosted backend

The generated `worker/index.js` / `dist/server/index.js` is a dependency-free Cloudflare Worker. Sites hosting uses `.openai/hosting.json` with D1 binding `DB`, and the schema-only migration in `dist/.openai/drizzle/`. The database is provisioned and migrated during publication. No external backend credentials are needed.

Classroom changes use an optimistic compare-and-swap on a D1 row with retry, preventing concurrent joins or votes from overwriting one another. Every browser polls at two-second intervals, and participant heartbeats refresh every fifteen seconds. Presence becomes Away after 45 seconds. This is near-real-time HTTP synchronization, not a WebSocket service. Timer/scenario timestamps come from the server. Writes validate role, phase, vote values and room credentials server-side. Aggregate change counts include only students who voted in both rounds, with a 3×3 anonymous transition matrix.

For independent Cloudflare hosting, deploy `worker/index.js` using a Worker with a D1 binding named `DB`; create the D1 database, apply `drizzle/0000_classrooms.sql` as a migration, and deploy with HTTPS. A sample `wrangler.toml` is included. Replace its database ID with the ID returned by `wrangler d1 create dam-village`, then run `wrangler d1 migrations apply dam-village --remote` and `wrangler deploy`. This needs a Cloudflare account and Wrangler. Sites publication is the preferred path when available.

Rooms are not automatically deleted. Use fictional nicknames; keep recovery keys private. The server stores votes to compute matched changes, but the UI/API returns no other participant’s choices. This is anonymous presentation, not cryptographic anonymity from the database owner. For a long-lived public service, add infrastructure rate limiting and an administrator data-retention policy.

## Readings and provenance

- Schmitt, R. J. P. & Rosa, L. (2024), *Dams for hydropower and irrigation: Trends, challenges, and alternatives*. DOI: https://doi.org/10.1016/j.rser.2024.114439
- Gleick, P. H. (2003), *Global Freshwater Resources: Soft-Path Solutions for the 21st Century*. https://pacinst.org/wp-content/uploads/2013/02/science_112003.pdf

The original uploaded PDFs and screenshot were unavailable in this workspace, and the original-chat reader was not exposed. The cached discussion requirements were used; a public Gleick full text and bibliographic/abstract information for Schmitt & Rosa were inspected. No original screenshot was used. Cards/prompts are fictional teaching scaffolds, not extracted quotations, calculations, site assessments, or empirical predictions. They ask students to supply evidence from their assigned PDFs. No numerical environmental forecasts are invented.

The map is original SVG artwork, with reduced-motion support, responsive phone views, keyboard-focus indicators, accessible labels and a focus-contained recovery dialog. All scenarios are explicitly labeled illustrative. Alternatives are not represented as impact-free or universally sufficient.

## Verification

Automated tests exercise 21 concurrent student joins with four guides; balancing, rejoin identity, duplicate nickname rejection, private role projections, forbidden host/guide actions, phase restrictions, vote updates, incomplete-round confirmation, recommendations, timer pause/resume, matched before/after results, both futures, invalid requests, and cross-origin protection. Browser UI checks are recorded in `VERIFICATION.md`.

## UCSB and QR update

Navy/gold digital colors use UCSB’s public palette (#003660 / #FEBC11). The original tower/coast illustrations and plain-text campus label identify a student project. Host **Join QR** shows a projector-safe student-only invite with the six-character room code, Copy link and Download QR. **Invite & keys** also includes the QR but contains private guide/host keys and should not be projected. QR encoding uses qrcode-generator 1.4.4 (MIT, vendored and embedded), without a remote QR service. See GITHUB-PAGES.md for the github.io frontend and cross-origin backend setup.

### Guide isolation and reading notes
Host, student, and guide credentials are saved separately and recovery checks the exact role. Guides have fixed map positions, never occupy student allocation slots, never count in voting, and cannot change phases, timers, or futures. An authenticated guide can join for the results debrief without changing anonymous results. Share each guide's own group key; keep the host recovery key private.

Guide-only talking points translate the readings into each stakeholder’s arguments, concerns, possible conditions, and questions for other groups. Students can expand a shorter set for their own role. The UI contains no paper summaries, PDF links, chapter markers, or reading assignments. Source provenance remains here: Schmitt & Rosa (2024), §4.2 (shared storage/release timing, renewable variability, and aquifer recharge limits), and Gleick (2003), pp. 1524, 1526–1527 (dam impacts, water services, productivity, participation, equity, ecological needs). These are original role-play prompts, not quotations or prescribed positions. Village impacts remain illustrative.
