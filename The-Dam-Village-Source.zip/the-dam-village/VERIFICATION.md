# Verification record

- Automated integration tests passed with 21 concurrent student joins plus four guides. Tests cover balanced allocations, stable rejoin, duplicate names, vote/host/guide restrictions, private responses, two rounds, timers, recommendations, matched change counts, scenarios and invalid/cross-origin requests.
- Generated Worker passes ESM export validation. Served HTML and its browser script parse successfully.
- Local HTTP server serves the real student and admin experiences. Browser checks verified creating a room, recovery-key dialog, student joining, host roster synchronization, restored identity in a new tab, saving a first vote, host advancement through discussion/debate/final voting, final change counts, projector mode, the complete dam animation, and alternative benefits/limits.
- Desktop map rendering visually inspected. Responsive student layout checked at a 390 × 844 viewport. Keyboard focus and dialog focus containment implemented; no screen-reader audit claimed.
- Synchronization uses 2-second polling; these were browser tabs on one computer, plus API concurrency tests, not a live campus class or physical-device network test.
- Public production Worker and D1 smoke test passed: nine concurrent students, four guides, balanced groups, both voting rounds, nine matched changes, and both scenario controls.
- Visual QA caught and corrected SVG opacity specificity hiding the reservoir/dam/alternative facilities; final computed visibility was checked in the browser.

2026-10-13 public ballot update: automated classroom, role, conditional-vote and story suites passed. Local browser checked blank condition rejection, saved first-round reason, all three projector gestures, clickable condition bubble, unchanged positions on ballot updates, first-vote-only student arguments, empty second-round draft and mandatory second-round reason. Existing private ballots remain private.
